class Katze: Tier() {
    override fun machtKrach() {
        super.machtKrach()
      println("Miau")
    }
}