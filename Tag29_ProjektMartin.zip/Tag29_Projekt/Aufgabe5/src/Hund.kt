open class Hund:Tier() {
     final override fun machtKrach(){
        super.machtKrach()
       println("Woof")
    }
}
