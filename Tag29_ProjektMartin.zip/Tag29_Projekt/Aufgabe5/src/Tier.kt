open class Tier {
    open fun machtKrach() {
     println("Tier macht Krach")
    }

}