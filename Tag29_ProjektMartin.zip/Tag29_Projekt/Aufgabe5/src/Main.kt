fun main(){
    var hund=Hund()
    var katze=Katze()

    hund.machtKrach()
    katze.machtKrach()
}