fun main(){
    var katze = Katze("Mautzi","Schwarz")
    katze.maunzen()
    katze.farbAendern()  // Punktnotation
}