class Katze ( var name:String,var farbe:String){
    fun maunzen(){
        println("Miau")
    }
    fun farbAendern(){
        farbe="Blau"
        println(farbe)
    }


}