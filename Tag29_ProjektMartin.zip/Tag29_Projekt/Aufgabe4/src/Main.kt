fun main(){
    var computer=Computer()
    computer.sendEMail()
    computer.pressOnButton()
    computer.sendEMail()
    computer.pressOffButton()
    println(computer.isOn)
}