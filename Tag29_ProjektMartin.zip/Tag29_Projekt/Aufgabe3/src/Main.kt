fun main(){
    var person = Person ("Hans",234567,37) // Konstruktor!!
    person.sprechen()
    person.vorstellung()


}