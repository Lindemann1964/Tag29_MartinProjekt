class Hund(var name: String, var Rasse: String) {
    fun bellen() {
        println("woof")
    }


}



