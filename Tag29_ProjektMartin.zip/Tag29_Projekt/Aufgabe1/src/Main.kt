fun main(){

    var hund1=Hund("Bello","Golden-Redriever")
    hund1.bellen()

}